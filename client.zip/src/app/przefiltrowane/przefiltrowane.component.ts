import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-przefiltrowane',
  templateUrl: './przefiltrowane.component.html',
  styleUrls: ['./przefiltrowane.component.scss']
})
export class PrzefiltrowaneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
